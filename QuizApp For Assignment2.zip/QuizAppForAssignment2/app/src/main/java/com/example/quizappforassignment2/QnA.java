package com.example.quizappforassignment2;

public class QnA {

    public static String question[] = {
            "Which state is the capital of Malaysia?",
            "Which of the following is not a programming languages?",
            "Which animals are endangered species?",
            "Which of the following is considered as fruits?",
            "Which company owns Apple?"
    };

    public static String choices[][] = {
            {"Kuala Lumpur","Penang","Melaka","Sabah"},
            {"Java","C++","Python","Chinese"},
            {"Amur Leopard","Cat","Dog","Chicken"},
            {"Durian", "Apple watch", "Pineapple pen", "Blackberry phone"},
            {"SAMSUNG","Apple","Huawei","Playstation"}
    };

    public static String correctAnswers[]={
            "Kuala Lumpur",
            "Chinese",
            "Amur Leopard",
            "Durian",
            "Apple"

    };
}
